﻿document.addEventListener('DOMContentLoaded', () => {
    const cells = document.querySelectorAll('.cell');
    const xWinsDisplay = document.getElementById('xWins');
    const oWinsDisplay = document.getElementById('oWins');
    const resetButton = document.getElementById('resetButton');

    let board = Array(9).fill(null);
    let currentPlayer = 'X';
    let xWins = 0;
    let oWins = 0;

    cells.forEach(cell => {
        cell.addEventListener('click', () => {
            const index = cell.dataset.index;
            if (!board[index]) {
                board[index] = currentPlayer;
                cell.textContent = currentPlayer;
                cell.classList.add(currentPlayer);

                if (checkWin(board, currentPlayer)) {
                    alert(`${currentPlayer} wins!`);
                    updateScore(currentPlayer);
                    resetGame();
                } else if (board.every(cell => cell)) {
                    alert('It\'s a tie!');
                    resetGame();
                } else {
                    currentPlayer = currentPlayer === 'X' ? 'O' : 'X';
                }
            }
        });
    });

    function checkWin(board, player) {
        const winPatterns = [
            [0, 1, 2], [3, 4, 5], [6, 7, 8],
            [0, 3, 6], [1, 4, 7], [2, 5, 8], 
            [0, 4, 8], [2, 4, 6] 
        ];

        return winPatterns.some(pattern => {
            return pattern.every(index => board[index] === player);
        });
    }

    function updateScore(player) {
        if (player === 'X') {
            xWins++;
            xWinsDisplay.textContent = xWins;
        } else {
            oWins++;
            oWinsDisplay.textContent = oWins;
        }
    }

    function resetGame() {
        board = Array(9).fill(null);
        cells.forEach(cell => {
            cell.textContent = '';
            cell.classList.remove('X', 'O');
        });
        currentPlayer = 'X';
    }

    resetButton.addEventListener('click', resetGame);
});
